import React from "react";
import {
  Bolt,
  Home,
  CircleArrowRight,
  MessageCircleMore,
  Ellipsis,
  Bell,
  Unplug,
  TrendingUp,
  Users,
  UserCircle,
  FileText,
  AtSign,
  Book,
  Server,
  Activity,
  Palette,
  Code,
  BarChart3
} from "lucide-react";

// Map icon names defined in menuConfig.json to their components
export const iconMap: Record<string, React.ComponentType<any>> = {
  Server,
  Bolt,
  Home,
  CircleArrowRight,
  MessageCircleMore,
  Ellipsis,
  Bell,
  Unplug,
  TrendingUp,
  Users,
  UserCircle,
  FileText,
  AtSign,
  Book,
  Activity,
  Palette,
  Code,
  BarChart3,
};
